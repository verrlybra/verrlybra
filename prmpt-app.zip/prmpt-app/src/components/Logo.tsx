import { motion } from 'motion/react'
import { EASE_OUT } from '../lib/assets'

export default function Logo() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: EASE_OUT, delay: 0 }}
      className="fixed z-20 pointer-events-none top-[16px] left-[16px] lg:top-[32px] lg:left-[32px] w-[124px] sm:w-[266px] lg:w-[355px]"
      style={{ mixBlendMode: 'exclusion' }}
    >
      <svg viewBox="0 0 355 110" width="100%" xmlns="http://www.w3.org/2000/svg">
        <text
          x="0"
          y="72"
          fontFamily="'Inter Tight', sans-serif"
          fontWeight="500"
          fontSize="72"
          letterSpacing="-4"
          fill="white"
        >
          prmpt
        </text>
        <circle cx="330" cy="30" r="22" stroke="white" strokeWidth="2.5" fill="none" />
        <text
          x="330"
          y="39"
          fontFamily="'Inter Tight', sans-serif"
          fontWeight="500"
          fontSize="24"
          fill="white"
          textAnchor="middle"
        >
          R
        </text>
      </svg>
    </motion.div>
  )
}
