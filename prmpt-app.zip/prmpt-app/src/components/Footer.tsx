export default function Footer() {
  return (
    <div
      id="outro-footer"
      className="fixed z-20 pointer-events-none flex left-[16px] right-[16px] bottom-[24px] lg:right-auto lg:bottom-[32px] justify-between lg:justify-start lg:gap-[80px]"
      style={{ mixBlendMode: 'exclusion', opacity: 0 }}
    >
      <span
        className="uppercase text-white text-[11px] lg:text-[13px]"
        style={{ fontFamily: "'Inter Tight', sans-serif", fontWeight: 500, letterSpacing: '-0.02em' }}
      >
        PRMPT (R) 2026
      </span>
      <span
        className="uppercase text-white text-[11px] lg:text-[13px]"
        style={{ fontFamily: "'Inter Tight', sans-serif", fontWeight: 500, letterSpacing: '-0.02em' }}
      >
        PRIVACY POLICY
      </span>
    </div>
  )
}
