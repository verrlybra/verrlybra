import { useEffect, useRef, useState } from 'react'
import { VIDEO_LEFT, VIDEO_RIGHT } from '../lib/assets'

type ActiveSide = 'left' | 'right'

export default function VideoBackground({ isTouch }: { isTouch: boolean }) {
  const containerRef = useRef<HTMLDivElement>(null)
  const leftRef = useRef<HTMLVideoElement>(null)
  const rightRef = useRef<HTMLVideoElement>(null)
  const mouseXRef = useRef<number | null>(null)
  const activeSideRef = useRef<ActiveSide>('right')
  const rafRef = useRef<number | null>(null)
  const [loaded, setLoaded] = useState({ left: false, right: false })
  const bothLoaded = loaded.left && loaded.right

  // Track loaded state so we can fade the container in once both videos
  // have enough data to render a frame.
  useEffect(() => {
    const left = leftRef.current
    const right = rightRef.current
    if (!left || !right) return

    const onLeft = () => setLoaded((s) => ({ ...s, left: true }))
    const onRight = () => setLoaded((s) => ({ ...s, right: true }))

    left.addEventListener('loadeddata', onLeft)
    right.addEventListener('loadeddata', onRight)
    return () => {
      left.removeEventListener('loadeddata', onLeft)
      right.removeEventListener('loadeddata', onRight)
    }
  }, [])

  // Desktop: scrub videos by cursor X position.
  useEffect(() => {
    if (isTouch) return
    const container = containerRef.current
    const left = leftRef.current
    const right = rightRef.current
    if (!container || !left || !right) return

    function handleMove(e: MouseEvent) {
      mouseXRef.current = e.clientX
    }
    window.addEventListener('mousemove', handleMove)

    function tick() {
      rafRef.current = requestAnimationFrame(tick)
      if (mouseXRef.current === null) return
      const rect = container!.getBoundingClientRect()
      const width = rect.width
      const centerX = rect.left + width / 2
      const deadZone = Math.max(30, width * 0.05)
      const x = mouseXRef.current
      const distFromCenter = x - centerX

      let activeVideo: HTMLVideoElement
      let inactiveVideo: HTMLVideoElement
      let progress = 0

      if (Math.abs(distFromCenter) <= deadZone) {
        // Inside dead zone: keep showing whichever side was last active,
        // holding both at frame 0 rather than snapping.
        activeVideo = activeSideRef.current === 'left' ? left! : right!
        inactiveVideo = activeSideRef.current === 'left' ? right! : left!
        progress = 0
      } else if (distFromCenter < 0) {
        // Cursor left of dead zone -> show RIGHT video.
        activeSideRef.current = 'right'
        activeVideo = right!
        inactiveVideo = left!
        const leftEdge = rect.left
        const zoneEdge = centerX - deadZone
        const available = Math.max(1, zoneEdge - leftEdge)
        progress = Math.min(1, Math.max(0, (zoneEdge - x) / available))
      } else {
        // Cursor right of dead zone -> show LEFT video.
        activeSideRef.current = 'left'
        activeVideo = left!
        inactiveVideo = right!
        const rightEdge = rect.left + width
        const zoneEdge = centerX + deadZone
        const available = Math.max(1, rightEdge - zoneEdge)
        progress = Math.min(1, Math.max(0, (x - zoneEdge) / available))
      }

      activeVideo.style.display = 'block'
      inactiveVideo.style.display = 'none'

      if (activeVideo.duration && !activeVideo.seeking) {
        const target = progress * activeVideo.duration
        if (Math.abs(activeVideo.currentTime - target) > 0.01) {
          activeVideo.currentTime = target
        }
      }
    }

    rafRef.current = requestAnimationFrame(tick)
    return () => {
      window.removeEventListener('mousemove', handleMove)
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
  }, [isTouch])

  // Mobile/tablet: alternate autoplay between the two videos.
  useEffect(() => {
    if (!isTouch) return
    const left = leftRef.current
    const right = rightRef.current
    if (!left || !right) return

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduceMotion) {
      left.style.display = 'block'
      right.style.display = 'none'
      left.pause()
      right.pause()
      return
    }

    left.style.display = 'block'
    right.style.display = 'none'
    left.currentTime = 0
    left.play().catch(() => {})

    function onLeftEnded() {
      left!.style.display = 'none'
      right!.style.display = 'block'
      right!.currentTime = 0
      right!.play().catch(() => {})
    }
    function onRightEnded() {
      right!.style.display = 'none'
      left!.style.display = 'block'
      left!.currentTime = 0
      left!.play().catch(() => {})
    }

    left.addEventListener('ended', onLeftEnded)
    right.addEventListener('ended', onRightEnded)
    return () => {
      left.removeEventListener('ended', onLeftEnded)
      right.removeEventListener('ended', onRightEnded)
    }
  }, [isTouch])

  return (
    <div
      id="main-canvas"
      ref={containerRef}
      className="fixed pointer-events-none overflow-hidden z-0 top-[220px] left-0 right-0 h-[calc(100vh-220px)] lg:top-0 lg:left-0 lg:right-0 lg:bottom-0 lg:h-auto"
      style={{
        opacity: bothLoaded ? 1 : 0,
        transition: 'opacity 0.3s ease',
      }}
    >
      <video
        ref={leftRef}
        src={VIDEO_LEFT}
        muted
        playsInline
        preload="auto"
        className="absolute inset-0 w-full h-full object-cover"
        style={{ display: 'none' }}
      />
      <video
        ref={rightRef}
        src={VIDEO_RIGHT}
        muted
        playsInline
        preload="auto"
        className="absolute inset-0 w-full h-full object-cover"
        style={{ display: 'block' }}
      />
    </div>
  )
}
