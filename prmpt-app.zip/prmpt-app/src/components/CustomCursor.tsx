import { useEffect, useRef } from 'react'

export default function CustomCursor({ isTouch }: { isTouch: boolean }) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (isTouch) return
    const el = ref.current
    if (!el) return

    function handleMove(e: MouseEvent) {
      if (!el) return
      el.style.left = `${e.clientX}px`
      el.style.top = `${e.clientY}px`
      el.style.opacity = '1'
    }

    window.addEventListener('mousemove', handleMove)
    return () => window.removeEventListener('mousemove', handleMove)
  }, [isTouch])

  if (isTouch) return null

  return (
    <div
      ref={ref}
      className="fixed z-50 pointer-events-none opacity-0"
      style={{
        transform: 'translate(-50%, -50%)',
        mixBlendMode: 'exclusion',
        transition: 'opacity 0.2s ease',
      }}
    >
      <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="24" cy="24" r="22.75" stroke="white" strokeWidth="2.5" />
        <path
          d="M24 13 L27 21 L35 24 L27 27 L24 35 L21 27 L13 24 L21 21 Z"
          fill="white"
        />
      </svg>
    </div>
  )
}
