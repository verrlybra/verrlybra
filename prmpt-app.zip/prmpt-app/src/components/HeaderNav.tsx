import { motion } from 'motion/react'
import { EASE_OUT } from '../lib/assets'

export default function HeaderNav() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: EASE_OUT, delay: 0.15 }}
      className="fixed z-20 pointer-events-none flex items-center justify-between top-[16px] right-[16px] lg:top-[32px] lg:right-[32px] w-auto lg:w-[330px] h-[30px]"
      style={{ mixBlendMode: 'exclusion' }}
    >
      <span
        className="hidden lg:inline uppercase text-white"
        style={{ fontFamily: "'Inter Tight', sans-serif", fontWeight: 500, fontSize: '15px' }}
      >
        ABOUT
      </span>
      <div className="flex items-center gap-[20px] lg:gap-[50px]">
        <svg
          className="w-[24px] h-[24px] lg:w-[30px] lg:h-[30px]"
          viewBox="0 0 40 40"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path d="M0 14H40" stroke="white" strokeWidth="2.5" />
          <path d="M0 26H40" stroke="white" strokeWidth="2.5" />
        </svg>
        <span
          className="text-white whitespace-nowrap"
          style={{
            fontFamily: "'Inter Tight', sans-serif",
            fontWeight: 500,
            fontSize: '13px',
          }}
        >
          <span className="lg:hidden">[ CART ]</span>
          <span className="hidden lg:inline text-[15px]">[ CART ]</span>
        </span>
      </div>
    </motion.div>
  )
}
