import { motion } from 'motion/react'
import { useEffect } from 'react'
import { EASE_OUT } from '../lib/assets'

export default function ProductInfo({ isMobile }: { isMobile: boolean }) {
  // Keep the data-outro-offset attribute in sync with breakpoint so the
  // scroll controller can read it without re-computing breakpoint logic.
  useEffect(() => {
    const el = document.getElementById('outro-info')
    if (el) el.dataset.outroOffset = isMobile ? '132' : '166'
  }, [isMobile])

  return (
    <motion.div
      id="outro-info"
      data-outro-offset={isMobile ? 132 : 166}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6, ease: EASE_OUT, delay: 0.45 }}
      className="fixed z-20 pointer-events-none flex flex-col items-center left-0 right-0 bottom-[48px] lg:left-auto lg:right-[32px] lg:bottom-[80px] lg:w-[330px]"
      style={{ mixBlendMode: 'exclusion' }}
    >
      <div className="flex flex-col items-start w-[252px] lg:w-full mb-[12px] lg:mb-[32px]">
        <div className="relative w-[20px] h-[20px] lg:w-[30px] lg:h-[30px] mb-2">
          <svg viewBox="0 0 40 40" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <circle
              cx="20"
              cy="20"
              r="18.75"
              stroke="white"
              strokeWidth="2"
              className="lg:hidden"
              fill="none"
            />
            <circle
              cx="20"
              cy="20"
              r="18.75"
              stroke="white"
              strokeWidth="2.5"
              className="hidden lg:block"
              fill="none"
            />
          </svg>
          <span
            id="circle-symbol"
            className="absolute inset-0 flex items-center justify-center uppercase text-white text-[10px] lg:text-[15px]"
            style={{
              fontFamily: "'Inter Tight', sans-serif",
              fontWeight: 500,
              letterSpacing: '-0.04em',
            }}
          >
            8
          </span>
        </div>
        <div
          className="uppercase text-white text-center w-full text-[20px] lg:text-[30px]"
          style={{
            fontFamily: "'Inter Tight', sans-serif",
            fontWeight: 500,
            lineHeight: '100%',
            letterSpacing: '-0.04em',
          }}
        >
          ARCHIVE COLLECTION
          <br />
          &quot;PROMPT&quot;
        </div>
      </div>
      <div
        className="text-white text-center text-[60px] lg:text-[80px]"
        style={{
          fontFamily: "'Inter Tight', sans-serif",
          fontWeight: 500,
          lineHeight: '100%',
          letterSpacing: '-0.04em',
        }}
      >
        $97,33
      </div>
    </motion.div>
  )
}
