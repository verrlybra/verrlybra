import { useEffect, useRef, useState } from 'react'
import { GALLERY_IMAGES } from '../lib/assets'
import { buildLayout, computeCardScale } from '../lib/layout'

function getCols() {
  const w = window.innerWidth
  if (w >= 1024) return 4
  if (w >= 640) return 3
  return 2
}

export default function GalleryPanel() {
  const [cols, setCols] = useState(getCols)
  const cardRefs = useRef<Map<number, HTMLDivElement>>(new Map())
  const rafRef = useRef<number | null>(null)

  useEffect(() => {
    function onResize() {
      setCols(getCols())
    }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  // Per-frame card scaling, independent of the outer scroll controller --
  // reads real, post-transform positions via getBoundingClientRect so it
  // stays correct through both the panel slide-up and the internal
  // gallery scroll phase.
  useEffect(() => {
    function tick() {
      rafRef.current = requestAnimationFrame(tick)
      const vh = window.innerHeight
      cardRefs.current.forEach((el) => {
        const rect = el.getBoundingClientRect()
        const scale = computeCardScale(rect.top, rect.bottom, vh)
        el.style.transform = `scale(${scale})`
      })
    }
    rafRef.current = requestAnimationFrame(tick)
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
  }, [])

  const rows = buildLayout(GALLERY_IMAGES.length, cols)
  const half = cols / 2

  return (
    <div className="w-full pt-[min(400px,40vh)] pb-[20vh]">
      <div
        className="grid gap-3 sm:gap-4 lg:gap-5 px-3 sm:px-4 lg:px-5"
        style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}
      >
        {rows.flatMap((row, rowIndex) =>
          row.map((cellValue, colIndex) => {
            const key = `${rowIndex}-${colIndex}`
            if (cellValue === -1) {
              return <div key={key} style={{ aspectRatio: '2/3' }} />
            }
            const origin = colIndex < half ? 'right bottom' : 'left bottom'
            return (
              <div key={key} style={{ aspectRatio: '2/3' }}>
                <div
                  ref={(el) => {
                    if (el) cardRefs.current.set(cellValue, el)
                    else cardRefs.current.delete(cellValue)
                  }}
                  className="bp-card w-full h-full overflow-hidden"
                  style={{ transform: 'scale(0)', transformOrigin: origin }}
                >
                  <img
                    src={GALLERY_IMAGES[cellValue]}
                    alt={`Archive piece ${cellValue + 1}`}
                    className="w-full h-full object-cover"
                    loading="lazy"
                    draggable={false}
                  />
                </div>
              </div>
            )
          }),
        )}
      </div>
    </div>
  )
}
