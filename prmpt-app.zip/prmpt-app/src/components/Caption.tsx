import { motion } from 'motion/react'
import { EASE_OUT } from '../lib/assets'

export default function Caption() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: EASE_OUT, delay: 0.3 }}
      className="fixed z-20 pointer-events-none left-[16px] lg:left-[32px] top-[118px] sm:top-[180px] lg:top-[244px] w-[calc(100vw-32px)] sm:w-[calc(50vw-48px)] lg:w-[692px]"
      style={{
        mixBlendMode: 'exclusion',
        fontFamily: "'Inter Tight', sans-serif",
        fontWeight: 500,
        fontSize: '12px',
        lineHeight: '140%',
        letterSpacing: '-0.04em',
        color: '#FFFFFF',
      }}
    >
      When switching between videos near the center, do not reset currentTime
      to 0 abruptly. Add a small dead zone: if cursor is within +/-50px of
      center, keep both videos at currentTime = 0 and show whichever was last
      active.
    </motion.div>
  )
}
