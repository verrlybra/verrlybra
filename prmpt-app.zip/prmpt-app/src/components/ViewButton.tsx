export default function ViewButton() {
  return (
    <div
      id="outro-buy"
      className="fixed z-20 pointer-events-none flex items-center justify-center left-[16px] right-[16px] bottom-[60px] h-[100px] lg:left-auto lg:right-[32px] lg:bottom-[32px] lg:w-[330px] lg:h-[174px]"
      style={{
        mixBlendMode: 'exclusion',
        transformOrigin: 'right bottom',
        transform: 'scale(0)',
        background: '#fff',
        borderRadius: '1335px',
      }}
    >
      <span
        className="text-[72px] lg:text-[110px]"
        style={{
          fontFamily: "'Inter Tight', sans-serif",
          fontWeight: 500,
          letterSpacing: '-0.04em',
          color: '#fff',
          mixBlendMode: 'exclusion',
        }}
      >
        view
      </span>
    </div>
  )
}
