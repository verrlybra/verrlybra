export type GridCell = number // index into the image array, or -1 for empty

/**
 * Scatters `count` images across a grid with `cols` columns.
 * Every row places one image at a "primary" column that shifts by two
 * (wrapping) each row, alternating with a one-column nudge on odd rows.
 * Every third row also places a second image nearby, so the grid never
 * reads as a strict repeating pattern.
 */
export function buildLayout(count: number, cols: number): GridCell[][] {
  const rows: GridCell[][] = []
  let r = 0
  let placed = 0

  while (placed < count) {
    const a = (r * 2 + (r % 2)) % cols
    const row: GridCell[] = new Array(cols).fill(-1)

    row[a] = placed
    placed++

    if (r % 3 === 0 && placed < count) {
      let b = (a + 2) % cols
      if (b === a) b = (a + 1) % cols
      row[b] = placed
      placed++
    }

    rows.push(row)
    r++
  }

  return rows
}

/**
 * Per-frame scale for a gallery card based on its current viewport position.
 * Grows in over the last 60% of viewport height as it enters from the
 * bottom, shrinks out over the top 40% of viewport height as it exits.
 */
export function computeCardScale(top: number, bottom: number, vh: number): number {
  if (bottom <= 0 || top >= vh) return 0
  const enter = Math.min(1, (vh - top) / (vh * 0.6))
  const exit = Math.min(1, bottom / (vh * 0.4))
  return Math.max(0, Math.min(enter, exit))
}
