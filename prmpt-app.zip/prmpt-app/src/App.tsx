import { useEffect, useRef, useState } from 'react'
import CustomCursor from './components/CustomCursor'
import Logo from './components/Logo'
import Caption from './components/Caption'
import HeaderNav from './components/HeaderNav'
import ProductInfo from './components/ProductInfo'
import ViewButton from './components/ViewButton'
import Footer from './components/Footer'
import VideoBackground from './components/VideoBackground'
import GalleryPanel from './components/GalleryPanel'
import { CIRCLE_SYMBOLS } from './lib/assets'

function detectTouch() {
  if (typeof window === 'undefined') return false
  return window.matchMedia('(pointer: coarse)').matches
}

export default function App() {
  const [isTouch, setIsTouch] = useState(false)
  const [isMobile, setIsMobile] = useState(false)

  const panelRef = useRef<HTMLDivElement>(null)
  const wrapperRef = useRef<HTMLDivElement>(null)
  const spacerRef = useRef<HTMLDivElement>(null)

  const maxScrollRef = useRef(0)
  const lastSymbolUpdateRef = useRef(0)
  const rafRef = useRef<number | null>(null)

  useEffect(() => {
    setIsTouch(detectTouch())
    function onResize() {
      setIsMobile(window.innerWidth < 640)
    }
    onResize()
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  // Recompute the spacer height whenever the gallery content or viewport
  // size changes, per: spacer = vh + maxScroll + 2*vh.
  useEffect(() => {
    function recomputeSpacer() {
      const vh = window.innerHeight
      const wrapper = wrapperRef.current
      if (!wrapper) return
      const wrapScrollHeight = wrapper.scrollHeight
      const maxScroll = Math.max(0, wrapScrollHeight - vh)
      maxScrollRef.current = maxScroll
      const spacer = spacerRef.current
      if (spacer) spacer.style.height = `${vh + maxScroll + 2 * vh}px`
    }

    recomputeSpacer()
    const ro = new ResizeObserver(recomputeSpacer)
    if (wrapperRef.current) ro.observe(wrapperRef.current)
    window.addEventListener('resize', recomputeSpacer)
    return () => {
      ro.disconnect()
      window.removeEventListener('resize', recomputeSpacer)
    }
  }, [])

  // Central scroll controller: panel slide-up, phase-2 internal scroll,
  // and the outro sequence (white overlay, product info slide, view
  // button scale, footer fade). Runs on RAF, not scroll events, so it
  // stays smooth regardless of how scroll events are throttled.
  useEffect(() => {
    function tick() {
      rafRef.current = requestAnimationFrame(tick)

      const vh = window.innerHeight
      const scrollY = window.scrollY
      const maxScroll = maxScrollRef.current

      const panel = panelRef.current
      const wrapper = wrapperRef.current
      if (!panel || !wrapper) return

      // Phase 1: panel slides up from vh to 0 as scrollY goes 0 -> vh.
      const phase1Progress = Math.min(1, Math.max(0, scrollY / vh))
      const panelTranslate = vh * (1 - phase1Progress)
      panel.style.transform = `translateY(${panelTranslate}px)`

      // Phase 2: panel pinned, inner wrapper scrolls internally.
      const phase2Scroll = Math.min(maxScroll, Math.max(0, scrollY - vh))
      wrapper.style.transform = `translateY(${-phase2Scroll}px)`

      // Outro: begins once scrollY passes vh + maxScroll.
      const outroStart = vh + maxScroll
      const outroProgress = Math.min(1, Math.max(0, (scrollY - outroStart) / Math.max(1, vh - 100)))

      const overlay = document.getElementById('outro-overlay')
      if (overlay) overlay.style.opacity = String(outroProgress)

      const buy = document.getElementById('outro-buy')
      if (buy) buy.style.transform = `scale(${outroProgress})`

      const footer = document.getElementById('outro-footer')
      if (footer) footer.style.opacity = String(outroProgress)

      const info = document.getElementById('outro-info')
      if (info) {
        const offset = parseFloat(info.dataset.outroOffset || '166')
        info.style.transform = `translateY(${-offset * outroProgress}px)`
      }

      // Hide the video layer once we've scrolled past the hero.
      const canvas = document.getElementById('main-canvas')
      if (canvas) canvas.style.visibility = scrollY >= vh ? 'hidden' : 'visible'

      // Randomize the circle glyph while scrolling, throttled to 80ms.
      const now = performance.now()
      if (scrollY > 0 && now - lastSymbolUpdateRef.current > 80) {
        lastSymbolUpdateRef.current = now
        const symbolEl = document.getElementById('circle-symbol')
        if (symbolEl) {
          const symbol = CIRCLE_SYMBOLS[Math.floor(Math.random() * CIRCLE_SYMBOLS.length)]
          symbolEl.textContent = symbol
        }
      }
    }

    rafRef.current = requestAnimationFrame(tick)
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
  }, [])

  return (
    <div
      id="scroll-spacer"
      ref={spacerRef}
      className="relative bg-white"
      style={{ userSelect: 'none', height: '500vh' }}
    >
      <CustomCursor isTouch={isTouch} />

      <Logo />
      <Caption />
      <HeaderNav />
      <ProductInfo isMobile={isMobile} />
      <ViewButton />
      <Footer />

      <VideoBackground isTouch={isTouch} />

      <div
        id="outro-overlay"
        className="fixed inset-0 pointer-events-none z-[12] bg-white"
        style={{ opacity: 0 }}
      />

      <div
        ref={panelRef}
        className="fixed inset-0 z-10 bg-black overflow-hidden"
        style={{ transform: 'translateY(100vh)' }}
      >
        <div ref={wrapperRef}>
          <GalleryPanel />
        </div>
      </div>
    </div>
  )
}
