# prmpt — Archive Collection

Full-screen, scroll-driven landing page. Video hero that scrubs by cursor
position, then a black gallery panel that slides up and reveals a scattered,
scale-in/out product grid, ending in a white "view" outro.

## Stack
React 19 · TypeScript · Vite · Tailwind CSS v4 · GSAP-ready · Motion (Framer Motion)

## Run locally
\`\`\`bash
npm install
npm run dev
\`\`\`
Then open the local URL it prints (usually http://localhost:5173).

## Build for production
\`\`\`bash
npm run build
\`\`\`
Output goes to `dist/`.

## Notes on this implementation
- The scroll system (panel slide-up, phase-2 internal scroll, gallery card
  scaling, outro sequence) runs on a single `requestAnimationFrame` loop for
  smoothness, rather than scroll event listeners.
- The logo wordmark and cursor glyph are placeholder vector shapes — swap the
  `<svg>` markup in `src/components/Logo.tsx` and `CustomCursor.tsx` for your
  real brand artwork.
- All video and image URLs point to the CloudFront/Higgs asset URLs supplied
  in the original spec.
